#include "KStudent.h"



KStudent::KStudent()
{
}


KStudent::~KStudent()
{
}
