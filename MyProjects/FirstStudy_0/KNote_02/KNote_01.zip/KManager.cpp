#include "KManager.h"
// iCnt ���� ���� �л��� �����ϰ� ����.
bool	KManager::InputData(int iCnt)
{
	for (int iStd = 0; iStd < iCnt; iStd++)
	{
		KStudent*	pStudent = new KStudent;
		for (int iName = 0;iName < 5;iName++)
		{
			char cWord = 65 + rand() % 26;
			pStudent->m_szName[iName] = cWord;
		}
		pStudent->m_szName[4] = 0;
		pStudent->m_iIndex = iStd;
		pStudent->m_Ssubject.m_iKor = rand() % 101;
		pStudent->m_Ssubject.m_iEng = rand() % 101;
		pStudent->m_Ssubject.m_iMat = rand() % 101;
		this->m_List.AddLink(pStudent);
	}
	return true;
}
KStudent*	KManager::Find(int iIndex)
{
	return NULL;
}
void	KManager::Sort(bool bUp = true)
{

}
void	KManager::Release()
{
	m_List.Release();
}
void	KManager::ShowData()
{
	for (KNode<KStudent>* pLink = m_List.m_pHead;pLink != NULL;pLink = pLink->m_pNext)
	{
		KStudent* pData = pLink->m_pData;
		wcout << pData->m_iIndex << " "
			<< pData->m_szName << " "
			<< pData->m_Ssubject.m_iKor << " "
			<< pData->m_Ssubject.m_iEng << " "
			<< pData->m_Ssubject.m_iMat << " "
			<< endl;
	}
}
void	KManager::ShowData(KStudent* pStd)
{

}

KManager::KManager()
{
}


KManager::~KManager()
{
}
