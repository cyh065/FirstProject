#pragma once
#include "KLinkedlist.cpp"
#include "KStudent.h"

class KManager
{
public:
	KLinkedlist<KStudent>	m_List;
public:
	bool	InputData(int iCnt);
	KStudent*	Find(int iIndex);
	void	Sort(bool bUp = true);
	void	Release();
	void	ShowData();
	void	ShowData(KStudent* pStd);
	void	Delete(int iIndex) {};
	void	Delete(KStudent* iData) {};
public:
	KManager();
	virtual ~KManager();
};

