#include "KSubject.h"



KSubject::KSubject()
{
}


KSubject::~KSubject()
{
}
