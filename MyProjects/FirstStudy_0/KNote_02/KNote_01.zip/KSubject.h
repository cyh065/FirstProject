#pragma once
#include <iostream>
#include <tchar.h>
using namespace std;

class KSubject
{
public:
	int		m_iKor;
	int		m_iEng;
	int		m_iMat;
public:
	KSubject();
	virtual ~KSubject();
};

