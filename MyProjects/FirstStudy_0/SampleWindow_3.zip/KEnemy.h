#pragma once
#include "KObject.h"
class KEnemy : public KObject
{
public:
	bool				Frame();
public:
	KEnemy();
	virtual ~KEnemy();
};

