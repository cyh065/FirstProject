#include "Sample.h"
#include "KSys.h"
bool		Sample::Init()
{
	m_BackGround.SetPos(0, 0, 0.0f);
	m_Hero.SetPos(400, 300, 30.0f);

	m_BackGround.Load(m_hScreenDC,
		m_hOffScreenDC, L"../../data/Bk.bmp");
	m_Hero.Load(m_hScreenDC,
		m_hOffScreenDC, L"../../data/Front.bmp");

	for (int iObj = 0; iObj < MAX_OBJECT; iObj++)
	{
		m_Object[iObj].SetPos(
			rand() % m_rtClient.right / 2,
			rand() % m_rtClient.bottom / 2,
			50.0f + rand() % 100);
		m_Object[iObj].Load(m_hScreenDC,
			m_hOffScreenDC, L"../../data/Front.bmp");
	}

	return true;
}
bool		Sample::Frame()
{
	for (int iObj = 0; iObj < MAX_OBJECT; iObj++)
	{
		m_Object[iObj].Frame();
	}
	if (m_Input.KeyCheck('W') == KEY_HOLD)
	{
		m_Hero.Up();
	}
	if (m_Input.KeyCheck('S') == KEY_HOLD)
	{
		m_Hero.Down();
	}
	if (m_Input.KeyCheck('A') == KEY_HOLD)
	{
		m_Hero.Left();
	}
	if (m_Input.KeyCheck('D') == KEY_HOLD)
	{
		m_Hero.Right();
	}
	if (m_Input.KeyCheck(VK_SPACE) == KEY_HOLD)
	{
		m_Hero.SetSpeed(50.0f);
	}
	else
	{
		m_Hero.SetSpeed(-100.0f);
	}
	return true;
}

bool		Sample::Render()
{
	m_BackGround.Render();
	//BitBlt(m_hScreenDC, 0, 0, 512, 512,			// �����ġ
	//	m_BackGround.m_hMemDC, 0, 0, SRCCOPY);	//����
	//BitBlt(m_hScreenDC, m_iX, m_iY, 128, 128,	// �����ġ
	//	m_Hero.m_hMemDC, 0, 0, SRCCOPY);		//����
	return true;
}
bool		Sample::Release()
{
	m_BackGround.Release();
	m_Hero.Release();
	for (int iObj = 0; iObj < MAX_OBJECT; iObj++)
	{
		m_Object[iObj].Release();
	}
	return true;
}
Sample::Sample()
{
	m_iX = 0;
	m_iY = 0;
}


Sample::~Sample()
{
}
int WINAPI wWinMain(
	HINSTANCE	hInstance,
	HINSTANCE	hPrevInstance,
	LPWSTR		lpCmdLine,
	int			nCmdShow)
{
	Sample Kwin;
	if (Kwin.SetWindow(hInstance) == true)
	{
		Kwin.Run();
	}
	return 0;
}